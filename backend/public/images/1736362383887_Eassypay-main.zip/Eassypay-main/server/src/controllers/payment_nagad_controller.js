import PayinTransaction from "../model/PayinTransaction.js";
import PayoutTransaction from "../model/PayoutTransaction.js";
import User from "../model/User.js";
import getCountryISO3 from "country-iso-2-to-3";
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { nanoid } from 'nanoid';
import ShortUniqueId from 'short-unique-id';
import querystring from 'querystring';
import crypto, { sign } from 'crypto';
import TelegramBot from 'node-telegram-bot-api';
import ForwardedSms from "../model/ForwardedSms.js";
import AgentNumber from "../model/AgentNumber.js";
import ApiAccountBkash from "../model/ApiAccountBkash.js";
import { fetchPayinTransactions } from "./client_controller.js";
import cron from 'node-cron';
import { NagadGateway } from 'nagad-payment-gateway';

const SERVER_URL = 'https://eassypay.com/api';
const BASE_URL = 'https://eassypay.com';

function generate256Hash(data) {
  // Use SHA256 to generate a hash
  const hash = crypto.createHash('sha256');
  hash.update(data);
  return hash.digest('hex');
}

const sleep = (ms) => {
  return new Promise(resolve => setTimeout(resolve, ms));
}

let NAGAD_URL = 'http://sandbox.mynagad.com:10080/remote-payment-gateway-1.0'; 
// let NAGAD_URL = 'http://mynagad.com:10080/remote-payment-gateway-1.0';

let NAGAD_CALLBACK_URL = SERVER_URL + '/payment/p2c/nagad/callback';

let NAGAD_MID = '683002007104225';  // sandbox
// let NAGAD_MID = '686057456165399';

let NAGAD_MNUMBER = '01605745616';

let NAGAD_MPRIVKEY = 'MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCJakyLqojWTDAVUdNJLvuXhROV+LXymqnukBrmiWwTYnJYm9r5cKHj1hYQRhU5eiy6NmFVJqJtwpxyyDSCWSoSmIQMoO2KjYyB5cDajRF45v1GmSeyiIn0hl55qM8ohJGjXQVPfXiqEB5c5REJ8Toy83gzGE3ApmLipoegnwMkewsTNDbe5xZdxN1qfKiRiCL720FtQfIwPDp9ZqbG2OQbdyZUB8I08irKJ0x/psM4SjXasglHBK5G1DX7BmwcB/PRbC0cHYy3pXDmLI8pZl1NehLzbav0Y4fP4MdnpQnfzZJdpaGVE0oI15lq+KZ0tbllNcS+/4MSwW+afvOw9bazAgMBAAECggEAIkenUsw3GKam9BqWh9I1p0Xmbeo+kYftznqai1pK4McVWW9//+wOJsU4edTR5KXK1KVOQKzDpnf/CU9SchYGPd9YScI3n/HR1HHZW2wHqM6O7na0hYA0UhDXLqhjDWuM3WEOOxdE67/bozbtujo4V4+PM8fjVaTsVDhQ60vfv9CnJJ7dLnhqcoovidOwZTHwG+pQtAwbX0ICgKSrc0elv8ZtfwlEvgIrtSiLAO1/CAf+uReUXyBCZhS4Xl7LroKZGiZ80/JE5mc67V/yImVKHBe0aZwgDHgtHh63/50/cAyuUfKyreAH0VLEwy54UCGramPQqYlIReMEbi6U4GC5AQKBgQDfDnHCH1rBvBWfkxPivl/yNKmENBkVikGWBwHNA3wVQ+xZ1Oqmjw3zuHY0xOH0GtK8l3Jy5dRL4DYlwB1qgd/Cxh0mmOv7/C3SviRk7W6FKqdpJLyaE/bqI9AmRCZBpX2PMje6Mm8QHp6+1QpPnN/SenOvoQg/WWYM1DNXUJsfMwKBgQCdtddE7A5IBvgZX2o9vTLZY/3KVuHgJm9dQNbfvtXw+IQfwssPqjrvoU6hPBWHbCZl6FCl2tRh/QfYR/N7H2PvRFfbbeWHw9+xwFP1pdgMug4cTAt4rkRJRLjEnZCNvSMVHrri+fAgpv296nOhwmY/qw5Smi9rMkRY6BoNCiEKgQKBgAaRnFQFLF0MNu7OHAXPaW/ukRdtmVeDDM9oQWtSMPNHXsx+crKY/+YvhnujWKwhphcbtqkfj5L0dWPDNpqOXJKV1wHt+vUexhKwus2mGF0flnKIPG2lLN5UU6rs0tuYDgyLhAyds5ub6zzfdUBG9Gh0ZrfDXETRUyoJjcGChC71AoGAfmSciL0SWQFU1qjUcXRvCzCK1h25WrYS7E6pppm/xia1ZOrtaLmKEEBbzvZjXqv7PhLoh3OQYJO0NM69QMCQi9JfAxnZKWx+m2tDHozyUIjQBDehve8UBRBRcCnDDwU015lQN9YNb23Fz+3VDB/LaF1D1kmBlUys3//r2OV0Q4ECgYBnpo6ZFmrHvV9IMIGjP7XIlVa1uiMCt41FVyINB9SJnamGGauW/pyENvEVh+ueuthSg37e/l0Xu0nm/XGqyKCqkAfBbL2Uj/j5FyDFrpF27PkANDo99CdqL5A4NQzZ69QRlCQ4wnNCq6GsYy2WEJyU2D+K8EBSQcwLsrI7QL7fvQ=='; 
// let NAGAD_MPRIVKEY = 'MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCiv0i8Fc/4iPD89lMWvaypJlmdU6/Ve8mVIo3qNEta9Q+MJFkm6KZgcpiXfR/Cj2+GNPDAKbAt60eH2kfNKx956MECfTLKpak1tMiphQmERD7R8Bvi16ambvuy5mtnbr0D7YZh7hznb0XgAUM9QP7XHmxVhrCpYoqdlzTRNKKLoNc+e1qrH9ICFr/VkNQXmDIfr/nSasuXdZ1wO1+oAHBklcCcGDvbktSWvyPR7ve54dRe9C0ghC9RVd7RrRD2FvYMeO4uWh23RwSfFFRHNgy82X9CSt0fZDuZfD/L+PcCPMBy+XbDf3P5EuH1lC7L9D6H3LjLuO7PTV3wfh/SgOyxAgMBAAECggEAeMg5tM0DYdJP94zgMVpnT8nUbDx1nJyYCIRyikRxQHnrJfi76XJ0N9QUhyknbv+ApzuXCSZnSEz680n+S7gbTiB9TdmY3mh/4gnfel/vpif371qhd4LQfWiUiDsVrteyk72uI/PRo7kjRJHrUwRvnTtI71hct/kYIsjbPAAyOijc9iP8NxBPWe6egCYRW3E1afFOkq8n1gqkYakaH5ROfJrxEMw0n6KlJPND0DcW93I7YZtHe7QqIQj/0V7OU9ipV5WSSYWsh/8P8oXsy8QbWWeTIG16CbmiTbGjz0KVNuD5NrPaNZPbHWpuTXFPfR5qU8yXiC/HnO6HgpnnibxQGQKBgQDnfHSDWsOWjt0ZWI/N8rNUdPE2jD7DO/Z1gsBJ6sop1KqkBlUGsKoAwxnPZq8luImT1GcUPmKDSZk3bT/NFsLgMgjJhP9DAxvPBuvr4K4nDV9MJmVLXUYM2lEi5/VG296Fg9HGwL2rMRIRi/wTL/ny91wlPcEwy84EBXnc4mHTEwKBgQCz+1RQ6dO1aWdltpJhRCfNDLlu/InwZGkMLXRet6w02fS+0GkvnD6K660dk8soHHn0VBJe4Ys8MA8YSit5e08BVdlOXN4kxY+lNi+h+8OJMIJlrfESmW8J1T5I4JHxroUi92xmv2Kr5lKWXl/r89LtlJ0F7yIdC5+U8jLvtHI1qwKBgAo6patoR1xP09Va5H/lSadhw4b1i5B1Bd8LeBPMHELc8u1smjVBeUGvXWSc1QCFtw6hRCzQ1OmYRvz8BuW5K8Nccqb1CZKcgI4VcDdsJkXzgVKMH83EwWOwAgXY2i3XaW3c9VgjDD6UXIgJ94mhhRoHdDrxD6hoWSI0W743AruhAoGAPHyFrJ+4t6oRxrwh27B1E9Nn6mXS0chdCWupRT/DDwwE1a/i+c4vsq5bwqntx7AySCuM9Pglu/eGyyn6DFylg5RfcJeDTKZcjTB1t6GN6Gg2GofnkdGg4JQa15EpWyjEs6ildK5zMcQ5EzHqWLjbtV6RmvHv7AUA/6SZ+7cP/vsCgYB1J3mwzazkPsiskUXplTdgw5XBMg3nQfYRLUuTBr+SA3QKP2RByY8dAaQMNgn0dTdaW1pv2Uy5hbgZIkhu9EQmdkj49n+LdEcfHiO4j81GnzH9vV7t1pS0qtIoTv4W5RnHmoJMmyweQUjFdsZAUlh/W0yceWyEYkhUmlkb1cBUZA==';
let NAGAD_NPUBKEY = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjBH1pFNSSRKPuMcNxmU5jZ1x8K9LPFM4XSu11m7uCfLUSE4SEjL30w3ockFvwAcuJffCUwtSpbjr34cSTD7EFG1Jqk9Gg0fQCKvPaU54jjMJoP2toR9fGmQV7y9fz31UVxSk97AqWZZLJBT2lmv76AgpVV0k0xtb/0VIv8pd/j6TIz9SFfsTQOugHkhyRzzhvZisiKzOAAWNX8RMpG+iqQi4p9W9VrmmiCfFDmLFnMrwhncnMsvlXB8QSJCq2irrx3HG0SJJCbS5+atz+E1iqO8QaPJ05snxv82Mf4NlZ4gZK0Pq/VvJ20lSkR+0nk+s/v3BgIyle78wjZP1vWLU4wIDAQAB'; 
// let NAGAD_NPUBKEY = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiCWvxDZZesS1g1lQfilVt8l3X5aMbXg5WOCYdG7q5C+Qevw0upm3tyYiKIwzXbqexnPNTHwRU7Ul7t8jP6nNVS/jLm35WFy6G9qRyXqMc1dHlwjpYwRNovLc12iTn1C5lCqIfiT+B/O/py1eIwNXgqQf39GDMJ3SesonowWioMJNXm3o80wscLMwjeezYGsyHcrnyYI2LnwfIMTSVN4T92Yy77SmE8xPydcdkgUaFxhK16qCGXMV3mF/VFx67LpZm8Sw3v135hxYX8wG1tCBKlL4psJF4+9vSy4W+8R5ieeqhrvRH+2MKLiKbDnewzKonFLbn2aKNrJefXYY7klaawIDAQAB';

const config = {
	apiVersion: 'v-0.2.0',
	baseURL: NAGAD_URL,
	callbackURL: NAGAD_CALLBACK_URL,
	merchantID: NAGAD_MID,
	merchantNumber: NAGAD_MNUMBER,
	privKey: NAGAD_MPRIVKEY,
	pubKey: NAGAD_NPUBKEY,
	isPath: false,
};

const nagad = new NagadGateway(config);

export const payment_nagad = async (req, res) => {
  const apiKey = req.headers['x-api-key']?req.headers['x-api-key']:'';
  const data = req.body;
  console.log('nagad-payment-data', data);

  if (!data.mid || !data.orderId || !data.payerId || !data.amount || !data.currency || !data.redirectUrl || !data.callbackUrl) { //
    return res.status(200).json({
      success: false,
      orderId: data.orderId,
      message: "Required fields are not filled out."
    })
  }

  if ((data.currency === "BDT" || data.currency === "INR") && parseFloat(data.amount) < 150) {
    return res.status(200).json({
      success: false,
      orderId: data.orderId,
      message: `Minimum deposit amount should be at least 150 for ${data.currency} currency.`
    })
  } else if (data.currency === "USD" && parseFloat(data.amount) < 10) {
    return res.status(200).json({
      success: false,
      orderId: data.orderId,
      message: "Minimum deposit amount should be at least 10 for USD currency."
    })
  }

  try {
    const merchant = await User.findOne({name: data.mid, status: 'activated'});
    if (data.mid !== 'merchant1' && (!merchant || merchant.apiKey !== apiKey)) {
      return res.status(200).json({
        success: false,
        orderId: data.orderId,
        message: "There is not existing activated merchant with API key"
      })
    }
    
    const payinTransaction = await PayinTransaction.findOne({
			orderId: data.orderId,
      merchant: data.mid
		});
		if (payinTransaction) {
      console.log('same order id for payment', data.orderId, payinTransaction.status);
			return res.status(200).json({
        success: false,
        orderId: data.orderId,
        message: "Transaction with duplicated order id, " + data.orderId + "."
      });  
		}

    // const apiAccountBkash = await ApiAccountBkash.findOne({ status: 'activated' });
    // if (data.mid !== 'merchant1' && !apiAccountBkash) {
    //   console.log('there is no activated bkash api account');
		// 	return res.status(200).json({
    //     success: false,
    //     orderId: data.orderId,
    //     message: "There is no available Bkash API account."
    //   });
    // } else if (data.mid !== 'merchant1' && apiAccountBkash) {
    //   BKASH_URL = 'https://tokenized.pay.bka.sh/v1.2.0-beta/tokenized/checkout';
    //   BKASH_USERNAME = apiAccountBkash.username;
    //   BKASH_PASSWORD = apiAccountBkash.password;
    //   BKASH_APP_KEY = apiAccountBkash.appKey;
    //   BKASH_APP_SECRET_KEY = apiAccountBkash.appSecretKey;
    // }

    const referenceId = `${Date.now()}`; // nanoid(16); // uuidv4();
    
    const nagadURL = await nagad.createPayment({
      // -> get intellisense here
      amount: data.amount,
      ip: data.clientIp,
      orderId: referenceId,
      productDetails: {},
      clientType: 'PC_WEB',
    });
    
    console.log('nagad-payment-create-resp', nagadURL); return;

    if (createObj.data.statusCode && createObj.data.statusCode === '0000') {
      const newTransaction = await PayinTransaction.create({
        paymentId: createObj.data.paymentID,
        merchant: data.mid,
        agentAccount: apiAccountBkash.accountNumber,
        provider: 'bkash',
        orderId: data.orderId,
        payerId: data.payerId,
        expectedAmount: data.amount,
        currency: data.currency,
        redirectUrl: data.redirectUrl,
        callbackUrl: data.callbackUrl,
        referenceId,
        submitDate: new Date(),
        paymentType: 'p2c'
      }); 

      return res.status(200).json({
        success: true,
        message: "Payment link created.",
        orderId: data.orderId,
        paymentId: createObj.data.paymentID,
        link: createObj.data.bkashURL
      })
    } else {
      console.log('nagad-payment-create-fail', createObj.data.errorCode, createObj.data.errorMessage);
      return res.status(200).json({
        success: false,
        orderId: data.orderId,
        message: "Internal Error"
      }); 
    }

  } catch (e) {

    console.log('nagad-payment-error', e.message);

    res.status(500).json({ 
      success: false,
      orderId: data.orderId,
      message: e.message 
    });

  }
};

export const callback_nagad = async (req, res) => {
  const data = req.body;
  console.log('nagad-callback-data', data); return;

  try {
    
    const transaction = await PayinTransaction.findOne({
			paymentId: data.paymentID
		});
		if (!transaction) {
      console.log('bkash-callback-no-transaction-with-paymentID', data.paymentID);
			return res.status(200).json({
        success: false,
        message: "There is no transaction with provided payment ID, " + data.paymentID + "."
      });  
		}

    res.status(200).json({
      success: true,
      // orderId: transaction.orderId,
      redirectUrl: transaction.redirectUrl
    }); 

    if (data.status !== 'success') return;

    if (transaction.status !== 'pending') {
      console.log('bkash-callback-transaction-already-done');
      return; 
    }

    const token = await get_token_bkash();
    if (!token) {
      console.log('bkash-token-is-null');
      return; 
    }
    
    const body = {
      paymentID: data.paymentID,
    };

    const executeObj = await axios.post(`${BKASH_URL}/execute`, body, {
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        'x-app-key': BKASH_APP_KEY,
        Authorization: token
      }
    });

    console.log('bkash-payment-execute-resp', executeObj.data); // return;

    if (executeObj.data.statusCode && executeObj.data.statusCode === '0000') {

      if (executeObj.data.transactionStatus === 'Initiated') {
        return fetch_bkash(data.paymentID);
      } else {
        let transaction_status = 'processing';

        if (executeObj.data.transactionStatus === 'Completed') {
          transaction_status = 'fully paid';
        } else if (executeObj.data.transactionStatus === 'Pending Authorized') {
          transaction_status = 'hold';
        } else if (executeObj.data.transactionStatus === 'Expired') {
          transaction_status = 'expired';
        } else if (executeObj.data.transactionStatus === 'Declined') {
          transaction_status = 'suspended';
        }

        const currentTime = new Date();
        transaction.status = transaction_status;
        transaction.statusDate = currentTime;
        transaction.transactionDate = currentTime;
        transaction.transactionId = executeObj.data.trxID;
        transaction.receivedAmount = executeObj.data.amount;
        transaction.payerAccount = executeObj.data.customerMsisdn;
        await transaction.save();
        
        if (transaction.callbackUrl && (transaction.status === 'fully paid' || transaction.status === 'expired' || transaction.status === 'suspended')) {
          
          const merchant = await User.findOne({name: transaction.merchant, role: 'merchant'});
          if (!merchant) throw Error('Merchant to callback does not exist');

          const hash = generate256Hash(transaction.paymentId + transaction.orderId + transaction.receivedAmount.toString() + transaction.currency + merchant.apiKey);

          let payload = {
            paymentId: transaction.paymentId,
            orderId: transaction.orderId,
            amount: transaction.receivedAmount,
            currency: transaction.currency,
            transactionId: transaction.transactionId,
            status: transaction.status,
            hash,
          };

          await axios
          .post(
            transaction.callbackUrl,
            payload,
            {
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
              },
            }
          )
          .then(async (resp) => {
            console.log('bkash-payment-execute-callback-to-mechant-resp', resp.data, resp.status);
            if (resp.status == 200) {
              transaction.sentCallbackDate = new Date();
              await transaction.save();
            }
            console.log('Callback has been sent to the merchant successfully'); 
          })
          .catch((e) => {
            console.log('bkash-payment-execute-callback-to-mechant-resp-error', e.message);
            console.log('Callback to the merchant failed');   
          });
        }
      }

    } else if (executeObj.data.statusCode) {
      console.log('bkash-payment-execute-others', executeObj.data.statusCode, executeObj.data.statusMessage); 
      return;
    } else if (executeObj.data.errorCode) {
      console.log('bkash-payment-execute-fail', executeObj.data.errorCode, executeObj.data.errorMessage);      
      
      if (transaction.status !== 'pending') {
        console.log('bkash-callback-transaction-already-done');
        return; 
      }

      const currentTime = new Date();
      transaction.status = 'suspended';
      transaction.statusDate = currentTime;
      await transaction.save();
      
      if (transaction.callbackUrl) {
        
        const merchant = await User.findOne({name: transaction.merchant, role: 'merchant'});
        if (!merchant) throw Error('Merchant to callback does not exist');

        const hash = generate256Hash(transaction.paymentId + transaction.orderId + '0' + transaction.currency + merchant.apiKey);

        let payload = {
          paymentId: transaction.paymentId,
          orderId: transaction.orderId,
          amount: 0,
          currency: transaction.currency,
          transactionId: null,
          status: transaction.status,
          hash,
        };

        await axios
        .post(
          transaction.callbackUrl,
          payload,
          {
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          }
        )
        .then(async (resp) => {
          console.log('bkash-payment-execute-callback-to-mechant-resp', resp.data);
          if (resp.data.success) {
            transaction.sentCallbackDate = new Date();
            await transaction.save();
          }
          console.log('Callback has been sent to the merchant successfully'); 
        })
        .catch((e) => {
          console.log('bkash-payment-execute-callback-to-mechant-resp-error', e.message);
          console.log('Callback to the merchant failed');   
        });
      }
    }

  } catch (e) {

    console.log('bkash-callback-error', e.message);

  }
};

const fetch_bkash = async (paymentID) => {
  
  console.log('bkash-fetch-data', paymentID);
  sleep(1000);

  try {
    
    const transaction = await PayinTransaction.findOne({
			paymentId: paymentID
		});
		if (!transaction) {
      console.log('bkash-fetch-no-transaction-with-paymentID', paymentID);
			return;  
		}

    const token = await get_token_bkash();
    if (!token) {
      console.log('bkash-token-is-null');
      return res.status(200).json({
        success: false,
        orderId: data.orderId,
        message: "Internal Error"
      }); 
    }
    
    const body = {
      paymentID
    };

    const queryObj = await axios.post(`${BKASH_URL}/payment/status`, body, {
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        'x-app-key': BKASH_APP_KEY,
        Authorization: token
      }
    });

    console.log('bkash-payment-query-resp', queryObj.data); // return;

    if (queryObj.data.statusCode && queryObj.data.statusCode === '0000') {
      
      if (queryObj.data.transactionStatus === 'Initiated') {
        fetch_bkash(paymentID);
      } else {
        let transaction_status = 'processing';

        if (queryObj.data.transactionStatus === 'Completed') {
          transaction_status = 'fully paid';
        } else if (queryObj.data.transactionStatus === 'Pending Authorized') {
          transaction_status = 'hold';
        } else if (queryObj.data.transactionStatus === 'Expired') {
          transaction_status = 'expired';
        } else if (queryObj.data.transactionStatus === 'Declined') {
          transaction_status = 'suspended';
        }

        const currentTime = new Date();
        transaction.status = transaction_status;
        transaction.statusDate = currentTime;
        transaction.transactionDate = currentTime;
        transaction.transactionId = queryObj.data.trxID;
        transaction.receivedAmount = queryObj.data.amount;
        transaction.payerAccount = queryObj.data.customerMsisdn;
        await transaction.save();
        
        if (transaction.callbackUrl && (transaction.status === 'fully paid' || transaction.status === 'expired' || transaction.status === 'suspended') && !transaction.sentCallbackDate) {
          
          const merchant = await User.findOne({name: transaction.merchant, role: 'merchant'});
          if (!merchant) throw Error('Merchant to callback does not exist');

          const hash = generate256Hash(transaction.paymentId + transaction.orderId + transaction.receivedAmount.toString() + transaction.currency + merchant.apiKey);

          let payload = {
            paymentId: transaction.paymentId,
            orderId: transaction.orderId,
            amount: transaction.receivedAmount,
            currency: transaction.currency,
            transactionId: transaction.transactionId,
            status: transaction.status,
            hash,
          };

          await axios
          .post(
            transaction.callbackUrl,
            payload,
            {
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
              },
            }
          )
          .then(async (resp) => {
            console.log('bkash-fetch-callback-to-mechant-resp', resp.data);
            if (resp.data.success) {
              transaction.sentCallbackDate = new Date();
              await transaction.save();
            }
            console.log('Callback has been sent to the merchant successfully'); 
          })
          .catch((e) => {
            console.log('bkash-fetch-callback-to-mechant-resp-error', e.message);
            console.log('Callback to the merchant failed');   
          });
        }
      }

    } else {
      console.log('bkash-payment-query-fail', queryObj.data.errorCode, queryObj.data.errorMessage);      
      const currentTime = new Date();
      transaction.status = 'suspended';
      transaction.statusDate = currentTime;
      await transaction.save();
    }

  } catch (e) {

    console.log('bkash-fetch-error', e.message);
    fetch_bkash(paymentID);

  }
};