import nagad from "../utils/nagadHelper.js";
import PayinTransaction from "../model/PayinTransaction.js";
import {
  sendErrorResponse,
  validateRequiredFields,
  validateAmount,
} from "../utils/validationHelper.js";

export const payment_nagad = async (req, res) => {
  try {
    const data = req.body;

    // API Key validation
    const apiKey = req.headers["x-api-key"] || "";
    if (!apiKey) {
      return sendErrorResponse(res, "API key is required.", data.orderId);
    }

    const merchant = await User.findOne({
      name: data.mid,
      status: "activated",
    });

    // Required fields validation
    const validationError = validateRequiredFields(data);
    if (validationError) {
      return sendErrorResponse(res, validationError, data.orderId);
    }

    // Amount validation
    const amountError = validateAmount(data.amount, data.currency);
    if (amountError) {
      return sendErrorResponse(res, amountError, data.orderId);
    }

    // Merchant validation
    if (data.mid !== "merchant1" && (!merchant || merchant.apiKey !== apiKey)) {
      return sendErrorResponse(
        res,
        "Invalid merchant or API key",
        data.orderId
      );
    }

    // Duplicate transaction check
    const existingTransaction = await PayinTransaction.findOne({
      orderId: data.orderId,
      merchant: data.mid,
    });
    if (existingTransaction) {
      return sendErrorResponse(
        res,
        `Transaction with duplicated order id, ${data.orderId}.`,
        data.orderId
      );
    }

    // Create Nagad payment
    const paymentConfig = {
      amount: data.amount,
      ip: data.ip,
      orderId: data.orderId,
      productDetails: { order_id: data.orderId },
      clientType: "PC_WEB",
    };

    const referenceId = `${Date.now()}`;
    let nagadResponse;

    try {
      nagadResponse = await nagad.createPayment(paymentConfig);
      console.log("nagad-payment-response", nagadResponse);
    } catch (error) {
      console.log(error);
      return sendErrorResponse(
        res,
        "Failed to create Nagad payment: " +
          (error.message || "Internal Error"),
        data.orderId
      );
    }

    if (!nagadResponse) {
      console.log("nagad-payment-creation-failed", nagadResponse);
      return sendErrorResponse(
        res,
        `Payment creation failed: ${nagadResponse.message || "Internal Error"}`,
        data.orderId
      );
    }

    // Create transaction record
    const newTransaction = await PayinTransaction.create({
      paymentId: nagadResponse.paymentId,
      merchant: data.mid,
      provider: "nagad",
      orderId: data.orderId,
      payerId: data.payerId,
      expectedAmount: data.amount,
      currency: data.currency,
      redirectUrl: data.redirectUrl,
      callbackUrl: data.callbackUrl,
      referenceId,
      submitDate: new Date(),
      paymentType: "p2c",
      status: "pending",
    });

    return res.status(200).json({
      success: true,
      message: "Payment link created.",
      orderId: data.orderId,
      paymentId: nagadResponse.paymentId,
      link: nagadResponse,
      referenceId,
    });
  } catch (error) {
    console.error("payment_nagad fatal error:", error);
    return sendErrorResponse(res, error.message, req.body?.orderId, 500);
  }
};
