import express from "express";
import {
  fetchUser,
  getDashboardStats,
  getChartStats,
  getPieStats,
  signin,
  signup,
  addUser,
  updateUser,
  updatePassword,
  deleteUser,
  addAgentNumber,
  updateAgentNumber,
  deleteAgentNumber,
  addApiAccountBkash,
  updateApiAccountBkash,
  deleteApiAccountBkash,
  deletePayinTransaction,
} from "../controllers/general_controller.js";

const router = express.Router();

// router.post("/register", signup);
// router.post("/login", signin);
router.get("/user/:id", fetchUser);
router.get("/dashboard", getDashboardStats);
router.get("/chart", getChartStats);
router.get("/pie", getPieStats);
router.post("/addUser", addUser);
router.post("/updateUser", updateUser);
router.post("/updatePassword", updatePassword);
router.post("/deleteUser", deleteUser);
router.post("/addAgentNumber", addAgentNumber);
router.post("/updateAgentNumber", updateAgentNumber);
router.post("/deleteAgentNumber", deleteAgentNumber);
router.post("/addApiAccountBkash", addApiAccountBkash);
router.post("/updateApiAccountBkash", updateApiAccountBkash);
router.post("/deleteApiAccountBkash", deleteApiAccountBkash);
router.post("/deletePayinTransaction", deletePayinTransaction);

export default router;
